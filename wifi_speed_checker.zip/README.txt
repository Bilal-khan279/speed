WiFi Speed Checker (Localhost Version)
----------------------------------------

INSTRUCTIONS:

1. Install XAMPP, WAMP, or use Live Server in VS Code.
2. Extract this folder into your local server's www or htdocs directory.
3. Start your local server.
4. Open http://localhost/wifi_speed_test in your browser.
5. Click "Start Test" to check your download speed using the local 10MB file.

Enjoy!
