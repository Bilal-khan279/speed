async function startTest() {
  const speedDisplay = document.getElementById("speed");
  speedDisplay.innerText = "Testing...";

  const testUrl = "10MB.zip?nocache=" + Math.random();

  const startTime = performance.now();

  try {
    const response = await fetch(testUrl);
    const reader = response.body.getReader();
    let bytesReceived = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytesReceived += value.length;
    }

    const endTime = performance.now();
    const durationInSeconds = (endTime - startTime) / 1000;
    const bitsLoaded = bytesReceived * 8;
    const speedMbps = (bitsLoaded / durationInSeconds / 1024 / 1024).toFixed(2);

    speedDisplay.innerText = `Speed: ${speedMbps} Mbps`;
  } catch (err) {
    speedDisplay.innerText = "Speed test failed. Try again.";
    console.error("Speed test error:", err);
  }
}
